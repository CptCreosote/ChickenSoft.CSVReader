﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace CSVReader
{
    public interface ICsv
    {
        FileInfo CsvFile { get; set; }
        DataTable Data { get; set; }
        IList<ICsvSchemaModel> Schema { get; set; }
    }
}
