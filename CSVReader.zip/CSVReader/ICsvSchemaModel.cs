﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVReader
{
    public interface ICsvSchemaModel
    {
        int ColumnIndex { get; set; }
        string ColumnName { get; set; }
        Type ColumnType { get; set; }
    }
}
