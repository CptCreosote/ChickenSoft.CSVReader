﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CSVReader
{
    public class Parser : ICsv
    {
        private FileInfo _csvFileInfo = null;
        private FileInfo _csvSchemaFileInfo = null;
        private readonly char _seperatorChar = Convert.ToChar(",");

        public FileInfo CsvFile { get; set; }
        public DataTable Data { get; set; }
        public IList<ICsvSchemaModel> Schema { get; set; }

        internal Parser()
        {            
        }

        public Parser(string csvFileName)
        {
            Initialize(csvFileName, null);
        }

        public Parser(string csvFileName, string csvSchemaFileName)
        {
            Initialize(csvFileName, csvSchemaFileName);
        }

        private void Initialize(string csvFileName, string csvSchemaFileName)
        {
            if (string.IsNullOrEmpty(csvFileName))
                throw new ArgumentNullException(nameof(csvFileName));

            _csvFileInfo = new FileInfo(csvFileName);

            if (!string.IsNullOrEmpty(csvSchemaFileName))
                _csvSchemaFileInfo = new FileInfo(csvSchemaFileName);

            Schema = new List<ICsvSchemaModel>();

            ParseSchema();

            if (Schema.Count == GetCsvColumnCount())
                CreateDataTableColumns();
        }

        private void ParseSchema()
        {
            if (_csvSchemaFileInfo == null) return;

            using (var schemaFile = new StreamReader(_csvSchemaFileInfo.FullName))
            {
                var schemaData = new object[3];

                do
                {
                    var schemaLine = schemaFile.ReadLine();

                    if (!string.IsNullOrEmpty(schemaLine) && schemaLine.Contains(_seperatorChar))
                        schemaLine.Split(_seperatorChar).CopyTo(schemaData, 0);

                    var schemaItem = new CsvSchemaModelModel
                    {
                        ColumnIndex = Convert.ToInt32(schemaData[0]),
                        ColumnName = Convert.ToString(schemaData[1]),
                        ColumnType = Type.GetType(Convert.ToString(schemaData[2]))
                    };

                    Schema.Add(schemaItem);
                } while (!schemaFile.EndOfStream);
            }
        }

        private int GetCsvColumnCount()
        {
            int maxColumnCount = 0;

            using (var csvFile = new StreamReader(_csvFileInfo.FullName))
            {
                do
                {
                    var columnCount = csvFile.ReadLine()?.Split(_seperatorChar).Length;

                    if (columnCount > maxColumnCount)
                        maxColumnCount = (int) columnCount;

                } while (!csvFile.EndOfStream);
            }

            return maxColumnCount;
        }

        private void CreateDataTableColumns()
        {

        }

        
    }
}
